# Changelog

All notable changes to this project will be documented in this file.

## [3.0.0] - 2026-02-09

### Added
- **Preset Renaming**: Right-click on any preset button to give it a custom name.
- **Image Enhancement**: New toggle to apply chosen filters to images and thumbnails across the web.
- **Improved Reset Logic**: The reset button (↺) now restores both settings and the original factory name.
- **Smart Revert**: Clearing a custom name and pressing enter now automatically reverts to the default preset name.

### Fixed
- **HTML Structure**: Fixed a rendering quirk caused by an orphaned closing div tag in the popup.
- **Badge Stability**: Improved storage listeners in the background script for more reliable "ON/OFF" badge updates.
- **Input Handling**: Fixed propagation issues when clicking inside the rename input field.

### Changed
- **Code Quality**: Completely humanized all codebase comments—short, concise, and developer-focused.
- **CSS Refinement**: Reverted to solid opaque backgrounds to ensure 100% visibility across different Linux compositor settings.
- **Version Bump**: Updated manifest version to 2.3.0.
